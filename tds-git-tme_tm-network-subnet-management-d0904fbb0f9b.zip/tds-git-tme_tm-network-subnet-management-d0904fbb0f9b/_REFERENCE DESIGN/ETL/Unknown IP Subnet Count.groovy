/******** TransitionManager ETL Script *******

Script Name: Unknown IP Subnet Count 

ETL Script Configuration: 
{
  "EtlScriptName": "Unknown IP Subnet Count",
  "ProviderName": "TransitionManager"
}


*/


/*
	Script: AppSubnets - count Subnet Dependencies Update Record
	Script Version: 1.3
	Minimum TM Version: 4.6.1
    Date: 2021-02-09
    Author: Brian daSilva

    Synopsys:

            
*/



//
// Iterate over the Selected Devices sent to this ETL script, Add it to a cache
//
read labels
iterate {



    // Create state Variables
    def depCount
    def subnetNumber = ''

    // Extrat Values
    extract 'Id' transform with toLong() set tmId
  //  extract 'Name' set devNameVar

    // Get the list of dependencies for this subnet that are 'In Subnets'

    
    find Dependency \
        by 'asset' eq tmId \
        and 'type' eq 'In Subnet' \
        fetch 'dependent' set inSubnetDependencies

    // Process the Dependency Results
    if(inSubnetDependencies){
        
        // Get the Dependency Count for the 'User Count'
        depCount = inSubnetDependencies.size()
        
        // Determine which class each Device is in.
        inSubnetDependencies.each { dep ->

        
        if (dep.dependent.moveBundle.toString() == 'Network Subnets') {

	    subnetNumber = dep.dependent.custom73
            
            
        
	}
     
}
     }

    // Create an Update record for the Application
    domain Device
    load 'id' with tmId
    load 'custom82' with subnetNumber 
    


}



