/******** TransitionManager ETL Script *******

Script Name: AppSubnets - Count Subnet Dependencies Update Record 

ETL Script Configuration: 
{
  "EtlScriptName": "AppSubnets - Count Subnet Dependencies Update Record",
  "ProviderName": "TransitionManager"
}


*/


/*
	Script: AppSubnets - count Sbunet Dependencies Update Record
	Script Version: 1.2
	Minimum TM Version: 4.6.1
    Date: 2020-11-24
    Author: Tony Baker
*/


//
// Iterate over the Selected Devices sent to this ETL script, Add it to a cache
//
read labels
iterate {

    // Extrat Values
    extract 'Id' set tmId
    extract 'Name' set subnetName

    // Get the list of dependencies for this subnet that are 'In Subnets'
    find Dependency \
        by 'dependent' eq tmId \
        and 'type' eq 'In Subnet' \
        fetch 'asset' set devicesInSubnetList
   
    // Convert the results into a Set
    def depCount
    if(devicesInSubnetList){
        depCount = devicesInSubnetList.size()
    }  else {
        depCount = 0
    }


    // Create an Update record for the Application
    domain Application
    load 'id' with tmId
    load 'assetName' with subnetName

    // Find any Subnet Dependencies from this record
    load 'User Count' with 'Devices in Subnet: ' + depCount
    

}






