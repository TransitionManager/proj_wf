/*********TransitionManager-ETL-Script*********

{
  "EtlScriptName": "Manage Subnets and VLANs (v1.0)",
  "Description": "",
  "ProviderName": "TransitionManager",
  "IsAutoProcess": true,
  "Target": null,
  "Mode": "Import"
}


*********TransitionManager-ETL-Script*********/

/*
	Script: Manage Subnets
	Script Version: 1.0
	Minimum TM Version: 4.6.1
    Date: 2020-11-24
    Author: Tony Baker
*/

//
// ETL Config Settings
//
def config = [
	create: [
        subnets: true,
        dependencies: [
            deviceToSubnet: true,
        ]
    ]
]



//
//  Define the Cache that is processed after Iterating
//
def cache = [
    // Key: TM ID,  Value:  [IP Address]
    deviceIPs: [:],

    // Key: CIDR_Address Value: TM ID
    subnetRanges: [:],

    // Key: DepKey, Value: DependencyMap
    dependencies: [:],

]

//
// IP Decimal Functions
//
def ipToLong  = { ipAddress ->

    // ipAddressInArray[0] = 192
    ipAddressInArray = ipAddress.split("\\.")

    long result = 0;
    for (int i = 0; i < ipAddressInArray.length; i++) {

        int power = 3 - i;
        int ip = Integer.parseInt(ipAddressInArray[i]);

        // 1. 192 * 256^3
        // 2. 168 * 256^2
        // 3. 1 * 256^1
        // 4. 2 * 256^0
        result += ip * Math.pow(256, power);
    }
    result
}

// def getSubnetLowAddress = { decIpAddress, prefixLength ->

//     // Calculate the network size from the prefix length (in decimal)
//     def prefixInt = prefixLength as Integer
//     def full = 4294967295
//     def blocks = full / prefixInt
//     def networkBlock = blocks * (prefixInt - 1)
//     networkBlock

// }

//
// Iterate over the data
//
read labels
iterate {

    // Don't process if there is a missing IP
    if(SOURCE.'IP Address'){
        
        // Cast the TM ID as a string to use as the cache key
        def tmId = SOURCE.'Id'.toString()

        //
        // Process Subnet Objects, which have an IP address range
        //
        if(SOURCE.'IP Address'.indexOf('-') > -1){

            // Add the Cidr address to the cache
            def lowIp = SOURCE.'IP Address'.toString().split('-')[0]
            def highIp = SOURCE.'IP Address'.toString().split('-')[1]
            def decimalLowIp = ipToLong(lowIp)
            def decimalHighIp = ipToLong(highIp)

            // Add the IP Range to the 
            cache.subnetRanges.put(lowIp, [
                low: decimalLowIp,
                high: decimalHighIp,
                tmId: tmId
            ])

        } else {

            //
            // Standard Device Object
            //

            // Read the IP Address field and make it an array of IPs
            def allIpAddresses = SOURCE.'IP Address'.toString().tokenize(',')
            
            // Find IP Addresses that have . or :
            def ipAddresses = allIpAddresses.findAll{ ipAddress ->
                
                // If the Address contains a dot 
                if(ipAddress.indexOf('.') > -1){
                    return true
                }
                
                return false
            }

            // Create a local cache of IP Addresses
            def deviceIPs = [:]

            // Add the IP List to the deviceIPs cache
            ipAddresses.each { ipAddress -> 
                def decimalIpAddress = ipToLong(ipAddress)
                deviceIPs.put(ipAddress, decimalIpAddress)
            }
            
            // Add the Device record to the cache of devices
            cache.deviceIPs.put(tmId, deviceIPs)


            console on

            // Set a unique list of the IPs
            def decimalDeviceIPs = deviceIPs.values() as String[]

            // Check to see if the Device has a Subnet Size, this allows creation of new Subnets
            if(SOURCE.'Network - Subnet Sizes' &&  (SOURCE.'Network - Subnet Sizes' != '')){

                // Get the list of Subnet Sizes so they can be paired with the IP to determine the network size
                def subnetSizes = SOURCE.'Network - Subnet Sizes'.split(',')
                
                // Set a counter
                def ipNumber = 0

                // Loop through the subnet sizes
                for (subnetSize in subnetSizes) {
                    
                    // Get the Decimal IP for this Subnet
                    def deviceDecimalIP = decimalDeviceIPs[ipNumber]
                    log 'This subnet size is: ' + subnetSize
                    log 'The Devices associated IPs are: ' + deviceDecimalIP
                    
                    // def subnetLowAddress = getSubnetLowAddress(deviceDecimalIP, subnetSizes)
                    log 'Subnet Low Address: ' + subnetLowAddress

                    // Get the Decimal IP to resize it for the low and high
                    // def decimalIpAddress = deviceIPs.getAt(ipNumber)

                    // log 'decimalIpAddress: ' + decimalIpAddress
                    
                    // Incremenet the counter
                    ipNumber++

                }
            }
                    console off
        }
    }
}



// 
// Process the Subnet Ranges, and check each Device/Device-IP
// 

if(cache.subnetRanges.size() > 0){

    // Subnet Range in the list
    cache.subnetRanges.each{ subnetTmId, subnetRange ->

        // For Each Device
        cache.deviceIPs.each { deviceTmId, deviceIPArray ->

            // Create a DepKey (Subnet to Device)
            def depKey = subnetTmId + '-' + deviceTmId
            
            /// For each of the Device's IPs
            deviceIPArray.each { ipAddress, decIpAddress ->

                // Check to see if a dependency for this pair already exists
                if(!cache.dependencies.containsKey(depKey)) {
                    
                    // Check to see if the IP Address is in the Subnet Range
                    if(decIpAddress > subnetRange.low && decIpAddress < subnetRange.high){
                        cache.dependencies.put(depKey, [
                            assetId: deviceTmId,
                            dependentId: subnetTmId,
                            type: 'In Subnet',
                            c3: 'Device IP: ' + ipAddress + ' is in Subnet Range',
                            c4: NOW
                        ])
                    }
                }
            }
        }
    }
}

//
//  Create the Resulting Dependencies
//
if(cache.dependencies.size() > 0){
    cache.dependencies.each { depKey, dependency ->

        // Create a Dependency Object
        domain Dependency
        
        // Find the Asset and Dependent
        find Device by 'id' eq dependency.assetId into 'asset'
        find Device by 'id' eq dependency.dependentId into 'dependent'

        // Load the Type and Status
        load 'type' with dependency.type
        load 'status' with 'Validated'
        load 'c3' with dependency.c3
        load 'c4' with dependency.c4


    }
}


