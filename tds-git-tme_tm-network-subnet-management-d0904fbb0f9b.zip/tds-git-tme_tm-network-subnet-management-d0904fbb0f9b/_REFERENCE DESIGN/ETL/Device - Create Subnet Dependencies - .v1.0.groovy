/******** TransitionManager ETL Script *******

Script Name: Device - Create Subnet Dependencies - .v1.0 

ETL Script Configuration: 
{
  "EtlScriptName": "Device - Create Subnet Dependencies - .v1.0",
  "ProviderName": "TransitionManager"
}


*/


/*
	Script: Manage Subnets
	Script Version: 1.1
	Minimum TM Version: 4.6.1
    Date: 2021-01-25
    Author: Tony Baker
*/

//
// ETL Config Settings
//
def config = [
	create: [
        subnets: true,
        dependencies: [
            deviceToSubnet: true,
        ]
    ]
]

//
//  Define the Cache that is processed after Iterating
//
def cache = [

    // Key: CIDR_Address Value: TM ID
    subnetRanges: [:],

    // assetId-subnetId List
    dependencies: [],

]

//
// IP Decimal Functions
//
def ipToLong  = { ipAddress ->

    // Get Each Octet separately
    // ipAddressInArray[0] = 192
    // ipAddressInArray[1] = 168
    // ipAddressInArray[2] = 1
    // ipAddressInArray[3] = 150
    ipAddressInArray = ipAddress.trim().split("\\.")

    long result = 0;
    for (int i = 0; i < ipAddressInArray.length; i++) {

        def octetString = ipAddressInArray[i].replaceAll(' ','')

        int power = 3 - i;
        
        int ip = Integer.parseInt(octetString);

        // 1. 192 * 256^3
        // 2. 168 * 256^2
        // 3. 1 * 256^1
        // 4. 2 * 256^0
        result += ip * Math.pow(256, power);
    }
    result
}


//
// Get all of the Subnet Assets to compute the range
//
find Application \
    by 'Bundle' eq 'Network Subnets - OOS' \
    and 'Data Source Types' eq 'Subnet' \
    fetch 'id', 'assetName', 'url', 'moveBundle' \
    set subnets
    // by 'Bundle' in ['Network Subnets', 'Network Subnets - OOS'] \

find Application \
    by 'Bundle' eq 'Network Subnets' \
    and 'Data Source Types' eq 'Subnet' \
    fetch 'id', 'assetName', 'url', 'moveBundle' \
    set oosSubnets

subnets.addAll(oosSubnets)

// For each subnet record, calculate the Decimal Range of the Subnet Scope
subnets.each { subnet -> 
    // Add the Cidr address to the cache
    def lowIp = subnet.'url'.toString().split('-')[0]
    def highIp = subnet.'url'.toString().split('-')[1]
    def decimalLowIp = ipToLong(lowIp)
    def decimalHighIp = ipToLong(highIp)

    // Add the IP Range to the 
    cache.subnetRanges.put(lowIp, [
        assetName: subnet.assetName,
        low: decimalLowIp,
        high: decimalHighIp,
        tmId: subnet.id,
        bundle: subnet.moveBundle,
        matchedDeviceCount: 0,
        matchedIPAddressCount: 0,
    ])
}


//
// Iterate over the Selected Devices
//
read labels
iterate {
    
    // Tag the Asset with the Subnets Tag
    domain Device
    extract 'Id' load 'id' set deviceId
    extract 'Name' load 'Name'
    extract 'IP Address' set ipAddress

    // Handle Tags
    tagAdd 'IP to Subnets Analyzed'
    // tagRemove 'TODO: Create Subnet Deps'

    //
    // Don't process if there is a missing IP
    //      or if the IP has a dash (for Subnets)
    if(ipAddress != '' && ipAddress.indexOf('-') == -1){
        

        // Find IP Addresses that have .
        List deviceIpAddresses = ipAddress.tokenize(',').toSet().toList()
        def matchedSubnet = false

        // Load the formatted list of IPs back to the device
        load 'IP Address' with deviceIpAddresses.join(', ')

        deviceIpAddresses.each{ ipAddress ->
            
            // Remove any surrounding whitespace
            ipAddress = ipAddress.replaceAll(' ','').replaceAll('   ','')

            // If the Address contains a dot  (IP v4 Addresses)
            if(ipAddress.indexOf('.') > -1){
       
                // Convert the IP to a Decimal for comparison to a range
                def decimalIpAddress = ipToLong(ipAddress)
                
                // Subnet Range in the list
                cache.subnetRanges.each { networkAddress, subnetRange ->

                    // Check to see if there is a dependency for this pair
                    if(!cache.dependencies.contains('TM' + deviceId + '-' + subnetRange.tmId)){

                        // Check the IP address against the low and high of the subnet
                        if((decimalIpAddress > subnetRange.low) && (decimalIpAddress < subnetRange.high)){

                            // Cache the dependency so it doesn't get created again
                            cache.dependencies.add('TM' + deviceId + '-' + subnetRange.tmId)
                            
                            // Update the Matched IP Count
                            subnetRange.matchedIPAddressCount++
                            subnetRange.matchedDeviceCount++
                            
                            // Mark the Device as Matched Subnet
                            matchedSubnet = true

                            // Test to see if the Subnet is OOS, if so, tag the device with "OOS Subnet"
                            if(subnetRange.bundle.toString() == 'Network Subnets - OOS'){
                                tagAdd 'OOS Subnet'
                            }
                        }
                    }
                }
            }
        }
        
        // If the Device did not match a subnet, add a tag
        if(!matchedSubnet){
            tagAdd 'Issue: No Subnet Matched'
        }
    }
}

//
// Create the dependencies
//
cache.dependencies.each { dependency ->

    def assetIds = dependency.replaceAll('TM','').tokenize('-')

    // Create a Dependency Object
    domain Dependency
    
    // Find the Asset and Dependent
    // find Device by 'id' eq assetIds[0] into 'asset'
    // find Device by 'id' eq assetIds[1] into 'dependent'
    load 'asset' with assetIds[0]
    load 'dependent' with assetIds[1]

    // Load the Type and Status
    load 'type' with 'In Subnet'
    load 'status' with 'Validated'
    load 'c3' with 'Subnet Management ETL'
    load 'c4' with NOW

    // Check the 'Asset' record and see if the 

    
}



//
// Update the Subnet Objects
//
cache.subnetRanges.each { key, subnet -> 

    // Find Dependencies for this Subnet
    // domain Dependency
    // find Dependency \
    //     by 'dependent' eq subnet.tmId \
    //     and 'type' eq 'In Subnet' \
    //     into 'id'
    
    // def dependencyCount = FINDINGS.size()
    // ignore record
    
    // Create an Update record for the Application
    domain Application
    load 'id' with subnet.tmId
    load 'Name' with subnet.assetName

    // Find any Subnet Dependencies from this record

    load 'User Count' with 'Matched IPs/Devices: ' + subnet.matchedIPAddressCount + ' / ' + subnet.matchedDeviceCount
    load 'comments' with 'IPs matched: ' + subnet.matchedIPAddressCount + ' on ' + subnet.matchedDeviceCount + ' TM Devices   ||   ' + NOW

}



