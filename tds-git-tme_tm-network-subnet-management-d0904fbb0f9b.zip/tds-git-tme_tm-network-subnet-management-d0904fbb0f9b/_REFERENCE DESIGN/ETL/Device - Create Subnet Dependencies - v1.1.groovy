/******** TransitionManager ETL Script *******

Script Name: Device - Create Subnet Dependencies - v1.1 

ETL Script Configuration: 
{
  "EtlScriptName": "Device - Create Subnet Dependencies - v1.1",
  "ProviderName": "TransitionManager"
}


*/


/*
	Script: Manage Subnets
	Script Version: 1.0
	Minimum TM Version: 4.6.1
    Date: 2020-11-24
    Author: Tony Baker
*/

//
// ETL Config Settings
//
def config = [
	create: [
        subnets: true,
        dependencies: [
            deviceToSubnet: true,
        ]
    ]
]

//
//  Define the Cache that is processed after Iterating
//
def cache = [

    // Cache of TM devices in the incoming data
    tmDevices: [],

    // Key: CIDR_Address Value: TM ID
    subnetRanges: [:],

    // assetId-subnetId List
    dependencies: [],

]

//
// IP Decimal Functions
//
def ipToLong  = { ipAddress ->

    // Get Each Octet separately
    // ipAddressInArray[0] = 192
    // ipAddressInArray[1] = 168
    // ipAddressInArray[2] = 1
    // ipAddressInArray[3] = 150
    ipAddressInArray = ipAddress.trim().split("\\.")

    long result = 0;
    for (int i = 0; i < ipAddressInArray.length; i++) {

        def octetString = ipAddressInArray[i].replaceAll(' ','')

        int power = 3 - i;
        
        int ip = Integer.parseInt(octetString);

        // 1. 192 * 256^3
        // 2. 168 * 256^2
        // 3. 1 * 256^1
        // 4. 2 * 256^0
        result += ip * Math.pow(256, power);
    }
    result
}


//
// Iterate over the Selected Devices sent to this ETL script, Add it to a cache
//
read labels
iterate {

    cache.tmDevices.add([
        'Id': SOURCE['Id'],
        'Name': SOURCE['Name'],
        'IP Address': SOURCE['IP Address']
    ])
}


//
// Get all of the Subnet Assets to compute the range
//
find Application \
    by 'Bundle' eq 'Network Subnets - OOS' \
    and 'Data Source Types' eq 'Subnet' \
    fetch 'id', 'assetName', 'url', 'moveBundle' \
    set subnets

find Application \
    by 'Bundle' eq 'Network Subnets' \
    and 'Data Source Types' eq 'Subnet' \
    fetch 'id', 'assetName', 'url', 'moveBundle' \
    set oosSubnets

subnets.addAll(oosSubnets)

// For each subnet record, calculate the Decimal Range of the Subnet Scope
// subnets.each { subnet -> 
    // console on
dataset subnets 
iterate {
    
    // Get the Subnet Dependency Assets to keep a knwon list of devices in the subnet
    // domain Dependency
    extract 'id' set tmId
    extract 'assetName' set assetName
    extract 'url' set url
    extract 'moveBundle' set moveBundle


    // Get the Dependency records already attached to this Subnet
    find Dependency \
        by 'dependent' eq tmId \
        and 'type' eq 'In Subnet' \
        fetch 'asset' set devicesInSubnetList
   
    // Convert the results into a Set
    Set devicesInSubnet
    if(devicesInSubnetList){
        devicesInSubnet = devicesInSubnetList.collect{ it.asset.id }.toSet()
    }  else {
        devicesInSubnet = [].toSet()
    }

    // Add the Cidr address to the cache
    def lowIp = SOURCE.'url'.toString().split('-')[0]
    def highIp = SOURCE.'url'.toString().split('-')[1]
    def decimalLowIp = ipToLong(lowIp)
    def decimalHighIp = ipToLong(highIp)

    // Add the IP Range to the 
    cache.subnetRanges.put('TM-'+ tmId, [
        assetName: assetName,
        low: decimalLowIp,
        high: decimalHighIp,
        tmId: tmId,
        bundle: moveBundle,
        tmDevicesInSubnet: devicesInSubnet,
        matchedDeviceCount: 0,
        matchedIPAddressCount: 0,
        updated: false,
    ])
}

    // console off

//
// Iterate over the Cache of etl Devices
//
dataset cache.tmDevices
iterate {
    
    // Tag the Asset with the Subnets Tag
    domain Device
    extract 'Id' load 'id' set deviceId
    extract 'Name' load 'Name'
    extract 'IP Address' set ipAddress

    // Handle Tags
    tagAdd 'IP to Subnets Analyzed'
    // tagRemove 'TODO: Create Subnet Deps'

    //
    // Don't process if there is a missing IP
    //      or if the IP has a dash (for Subnets)
    if(ipAddress != '' && ipAddress.indexOf('-') == -1){
        

        // Find IP Addresses that have .
        List deviceIpAddresses = ipAddress.tokenize(',').toSet().toList()
        def matchedSubnet = false

        // Load the formatted list of IPs back to the device
        load 'IP Address' with deviceIpAddresses.join(', ')

        deviceIpAddresses.each{ ipAddress ->
            
            // Remove any surrounding whitespace
            ipAddress = ipAddress.replaceAll(' ','').replaceAll('   ','')

            // If the Address contains a dot  (IP v4 Addresses)
            if(ipAddress.indexOf('.') > -1){
       
                // Convert the IP to a Decimal for comparison to a range
                def decimalIpAddress = ipToLong(ipAddress)
                
                // Subnet Range in the list
                cache.subnetRanges.each { networkAddress, subnetRange ->

                    // Check to see if there is a dependency for this pair
                    if(!cache.dependencies.contains('TM' + deviceId + '-' + subnetRange.tmId)){

                        // Check the IP address against the low and high of the subnet
                        if((decimalIpAddress > subnetRange.low) && (decimalIpAddress < subnetRange.high)){

                            // Cache the dependency so it doesn't get created again
                            cache.dependencies.add('TM' + deviceId + '-' + subnetRange.tmId)
                            
                            // Update the Matched IP Count
                            subnetRange.matchedIPAddressCount++
                            subnetRange.matchedDeviceCount++
                            subnetRange.tmDevicesInSubnet.add(deviceId)
                            subnetRange.updated = true
                            
                            // Mark the Device as Matched Subnet
                            matchedSubnet = true

                            // Test to see if the Subnet is OOS, if so, tag the device with "OOS Subnet"
                            if(subnetRange.bundle.toString() == 'Network Subnets - OOS'){
                                tagAdd 'OOS Subnet'
                            }
                        }
                    }
                }
            }
        }
        
        // If the Device did not match a subnet, add a tag
        if(!matchedSubnet){
            tagAdd 'Issue: No Subnet Matched'
        }
    }
}

//
// Create the dependencies
//
cache.dependencies.each { dependency ->

    def assetIds = dependency.replaceAll('TM','').tokenize('-')

    // Create a Dependency Object
    domain Dependency
    
    // Find the Asset and Dependent
    load 'asset' with assetIds[0]
    load 'dependent' with assetIds[1]

    // Load the Type and Status
    load 'type' with 'In Subnet'
    load 'status' with 'Validated'
    load 'c3' with 'Subnet Management ETL'
    load 'c4' with NOW

}



//
// Update the Subnet Objects
//
cache.subnetRanges.each { key, subnet -> 
    
    // Debugging
    console on
    // log subnet
    
    // Extract the ID
    // extract 'id' set tmId
    domain Application
    // load 'id' with subnet.tmId
    
    // Only update the subnet if it was matched in this ETL run
    if(subnet.updated){

        log subnet.updated

        // Create an Update record for the Application
        domain Application
        load 'id' with subnet.tmId
        load 'assetName' with subnet.assetName

        // Find any Subnet Dependencies from this record
        load 'User Count' with 'Devices in Subnet: ' + (subnet.tmDevicesInSubnet.size() - 1)
        load 'comments' with 'Total of Devices in this subnet: ' + (subnet.tmDevicesInSubnet.size()  - 1) +  '; The last ETL run matched  ' + subnet.matchedIPAddressCount + ' IP Addresses, on ' + subnet.matchedDeviceCount + ' TM Devices.     ||   ' + NOW
    }

}



