/******** TransitionManager ETL Script *******

Script Name: Networking - Identify IP Conflicts 

ETL Script Configuration: 
{
  "EtlScriptName": "Networking - Identify IP Conflicts",
  "ProviderName": "TransitionManager"
}


*/


/*
    Detect IP Conflicts
    Version: 1.0

    Summary:
        This script reads directly from the TM database.  It finds all devices which have an IP address.
        With this list, it makes a unique list of all IP addresses and records which assets have that IP address listed.
        With this 'Conflict List', each device is updated with a tag (Issue: IP Conflict) and a comment added for each conflicting IP address.
*/

List fetchFields = [
    'Id',
    'Name',
    'IP Address',
]

Map<Map> cache = [
    tmDevices: [:],
    ipAddresses: [:],
    deviceUpdates: [],
]

//////////////////////////////
// Script Functions
//////////////////////////////

// 
// Convert a Comma Delimited String to a set
// 
def commaStringToSet = { string  -> 

    // Create the valueSet to be returned
    Set valueSet = []

    // Skip any Null values
    if(!string){
        return valueSet
    }

    // Create a temporary list to hold the conversion results
    List list = []

    // If the String has a comma
    if(string.toString().indexOf(',') > -1){
        
        // Remove spaces after the commas
        string = string.replaceAll(', *', ',')
        
        // Fill the Temporary list with the values between the commas
        list = string.toString().tokenize(',')
    } 
    
    // The Value did not have a comma
    else {

        // Add the String to the list, all by it self
        list = [string.toString()]
    }

    // Convert the temporary list to the Returned valueSet
    valueSet = list.toSet()
    return valueSet
}

//
// Get a listing of all the devices with IPs
//
find Device \
    by 'IP Address' ne '' \
    fetch 'Id', 'Name', 'IP Address' \
    set allDevices

//
// Iterate over each of the found devices
//
allDevices.each { device ->

    // Convert the IP and mac to a Set
    def ipSet = commaStringToSet(device.ipAddress)
    
    // Add each IP to the IP List
    ipSet.each { ip ->

        // Ignore useless values
        if(['', 'none', 'unknown', '0', '0.0.0.0'].contains(ip)){
            return
        }

        // Add the Device ID to the IP Address's set
        if(!cache.ipAddresses.containsKey(ip)){
            Set deviceSet = [device]
            cache.ipAddresses.put(ip, deviceSet)
            // Set deviceIdSet = [device.id]
            // cache.ipAddresses.put(ip, deviceIdSet)
        } else {
            cache.ipAddresses[ip].add(device)
            // cache.ipAddresses[ip].add(device.id)
        }
    }

    // Add the Device to the cache
    cache.tmDevices.putAt('TM' + device.id, [
        id: device.id,
        assetName: device.assetName,
        ipSet: ipSet,
    ])
}

// Iterate over each of the Conflicts
def ipsWithMultipleDevices = cache.ipAddresses.findAll{ it.size() > 1 }
ipsWithMultipleDevices.each { ipAddress, deviceSet -> 
    
    // Create a list of Updates to make (one for each IP/Device)
    deviceSet.each{ device ->

        // Get the Names of the other devices that conflict
        def otherAssetNames = deviceSet.findAll{ it.id != device.id}.collect{it.assetName}
        def otherAssetIds = deviceSet.findAll{ it.id != device.id}.collect{it.id}
        
        // Add a Device Update for this Conflict
        cache.deviceUpdates.add([
            deviceId: device.id,
            deviceName: device.assetName,
            ipAddress: ipAddress,
            otherAssetNames: otherAssetNames,
            otherAssetIds: otherAssetIds
        ])
    }
}

// Process the Device Updates
Set dependenciesCreated = []
dataset cache.deviceUpdates
iterate {

    // Create a Device update record
    domain Device
    extract 'deviceId' load 'id' set deviceId
    extract 'deviceName' load 'Name' set deviceName

    // Get the IP Address and the 'Other device names'
    extract 'ipAddress' set ipAddress
    extract 'otherAssetNames' set otherAssetNames
    extract 'otherAssetIds' set otherAssetIds

    // Tag the Asset and Add a comment
    tagAdd 'Issue: IP Conflict'
    load 'comments' with 'An IP [' + ipAddress + '] on this device conflicts with the following device(s): ' + otherAssetNames

    // Log to the console
    console on
    log 'An IP [' + ipAddress + '] on this device [' + deviceName  + '] conflicts with the following device(s): ' + otherAssetNames
    
    // Create a Dependency to the other asset
    otherAssetIds.each {otherAssetId -> 
        
        // Create Keys to lookup this dependency by
        def depKeyA = 'd' + deviceId + 'd' + otherAssetId
        def depKeyB = 'd' + otherAssetId + 'd' + deviceId
        
        // If the Dependency hasn't been created yet
        if(!dependenciesCreated.contains(depKeyA) && !dependenciesCreated.contains(depKeyB)){
            
            // Cache that this dependency has already been created
            dependenciesCreated.add(depKeyA)
            dependenciesCreated.add(depKeyB)
        
            // Create the Dependency
            domain Dependency
            load 'asset' with deviceId
            load 'dependent' with otherAssetId
            load 'type' with 'IP Conflict'
            load 'status' with 'Validated'
            load 'c3' with 'IP Conflict with another device'
            load 'c4' with NOW
        }
    }
}




