/*********TransitionManager-ETL-Script*********

{
  "EtlScriptName": "AppSubnets - Update Subnet Summary  - v1.1",
  "Description": "Intended to run via Bulk Edit, on Subnet Asses.\nEach Subnet Asset is read, the dependencies for 'In Subnet' are collected and counted.  The count of Devices 'In Subnet' is then loaded to the 'User Count' field.",
  "ProviderName": "TransitionManager",
  "IsAutoProcess": false,
  "Target": null,
  "Mode": "Import"
}


*********TransitionManager-ETL-Script*********/

/*
	Script: AppSubnets - count Subnet Dependencies Update Record
	Script Version: 1.3
	Minimum TM Version: 4.6.1
    Date: 2020-11-24
    Author: Tony Baker

    Synopsys:
        - This Script is part 2 of the 'Manage Subnets' capability.  Part 1 has built 'In Subnet' dependencies between Subnets and Devices
        - This Part 2 Script does the following
            i -     Counts the total number of dependencies to this subnet
            ii -    Identifies the subnet as one of 4 SubnetTypes:
                    (Type 1) Contains Only VMware VMs
                    (2) Contains Type1 + Hyper-V VMs
                    (3) Devices with a Name (not '*IP:*')
                    (4) Devices with a name ( '*IP:*')
                    (100) Any Subnets that do not have any IP Dependencies
            iii -   This is done by reviewing Each server and determining which Class the Device Represents. 
                    The highest 'class' device present that is attached to the subnet is chosen as the Subnet's Type
            
*/

def conf = [
    subnet1: '1 - VMware VMs',
    subnet2: '2 - VMware and Hyper-V VMs',
    subnet3: '3 - VMs and Devices with Names',
    subnet4: '4 - Includes Unknown IP Devices',
    defaultSubnet: '100 - No Matched Devices',
]

//
// Iterate over the Selected Devices sent to this ETL script, Add it to a cache
//
read labels
iterate {

    // Build a Cache to count how many Type Objects
    def cache = [
        type1: 0,
        type2: 0,
        type3: 0,
        type4: 0,
    ]

    // Create state Variables
    def depCount
    def subnetType

    // Extrat Values
    extract 'Id' transform with toLong() set tmId
    extract 'Name' set subnetName

    // Get the list of dependencies for this subnet that are 'In Subnets'
    find Dependency \
        by 'dependent' eq tmId \
        and 'type' eq 'In Subnet' \
        fetch 'asset' set inSubnetDependencies

    // Process the Dependency Results
    if(inSubnetDependencies){
        
        // Get the Dependency Count for the 'User Count'
        depCount = inSubnetDependencies.size()
        
        // Determine which class each Device is in.
        inSubnetDependencies.each { dep ->

        
        if ((dep.asset.moveBundle.toString() != '4A Discovery-vRNI') && (dep.asset.moveBundle.toString() != '4A Discovery Network Devices')) {
            
            // Type 1: VMware VMs
            if(dep.asset.manufacturer.toString() == 'VMware' && dep.asset.model.toString() == 'VM'){
                cache.type1++
            }
            
            // Type 2: Hyper-V Guests
            else if(dep.asset.manufacturer.toString() == 'Microsoft' && dep.asset.model.toString() == 'Hyper-V Guest'){
                cache.type2++
            } 
            
            // Type 3: Devices have a Hostname, not an IP: Stub record
            else if(!dep.asset.assetName.matches(/.*IP\:.*/)){ cache.type3++ } 
            
            // Type 4: That are an IP: Name
            else { cache.type4++ } 
        }
	}
    }  else {
        subnetType = conf.defaultSubnet
        depCount = 0
    }

    // Process in Reverse order to find the highest numbered group
         if(cache.type4 > 0) { subnetType = conf.subnet4 } 
    else if(cache.type3 > 0) { subnetType = conf.subnet3 }
    else if(cache.type2 > 0) { subnetType = conf.subnet2 } 
    else if(cache.type1 > 0) { subnetType = conf.subnet1 }
    else { subnetType = conf.defaultSubnet }

    // Create an Update record for the Application
    domain Application
    load 'id' with tmId
    load 'assetName' with subnetName

    // Find any Subnet Dependencies from this record
    load 'User Count' with 'Devices in Subnet: ' + depCount

    set subnetSummary with 'Type: ' + subnetType + ' | VmwVMs |' + cache.type1 + ' | HypVM |' + cache.type2 + ' | Devices |' + cache.type3 + ' | IPs |' + cache.type4 + ' |]'

    load 'User Locations' with subnetSummary
    load 'Subnet Type' with subnetType
    load 'VmwVMs in Subnet' with cache.type1
    load 'HypVM in Subnet' with cache.type2
    load 'Other Devices in Subnet' with cache.type3
    load 'Unknown IPs in Subnet' with cache.type4


}








