/*********TransitionManager-ETL-Script*********

{
  "EtlScriptName": "Tag Device Category of subnet ",
  "Description": "this will tag a device with a tag stating what type of subnet categories it has",
  "ProviderName": "TransitionManager",
  "IsAutoProcess": false,
  "Target": null,
  "Mode": "Import"
}


*********TransitionManager-ETL-Script*********/

/**
*
* Script Name: ETL Managed Tags
*
* Version              : 1.0
* Author               : Erik Yi
* Authored             : 2021-03-09
* Minimum TM Version   : 4.6.5
*
* Invocation Method    : Bulk ETL Invocation
* Affected Assets      : Devices, Databases
*
*  SUMMARY
*  ============================
*  +   This is an Analysis ETL script, which consumes assets via Bulk Edit
*
*  +   The Purpose of this script is to reconcile device tags as they relate
*      to application dependencies. If a device supports applications in various bundles,
*      the device should be tagged using the bundle tags that are applicable.
*
*
*  SCRIPT FUNCTIONALITY
*  ============================
*
*  +   This Script is currently configured to use Devices and Databases, with specific Dependency Types and
*      statuses to locate important dependencies.  The Bundle the related asset is in, is also a tag.  This
*      tag is applied to the Device/Database
*
*  +   Devices also undergo a 'Platform' evaluation where 'Windows', 'Linux' and others are applied.
*
*  +   The applicable list of tags are considered 'ETL Managed'. The 'ETL Managed Tags'
*      are either added to or removed from the asset.  If any of these tags exist on the asset at
*      the time of processing, AND they are no longer applicable, the tag is removed.
*/

// --------------------------
// Configuration Settings
// --------------------------
Map config = [

    applicationBundleToTagLabel: [
        '1 - VMware VMs' : 'Cat 1',
        '2 - VMware and Hyper-V VMs': 'Cat 2',
        '3 - VMs and Devices with Names': 'Cat 3',
        '4 - Includes Unknown IP Devices': 'Cat 4'
    ],
    validDependencyStatus: [
        'Validated'
    ],
    validDependencyType: [
        'In Subnet'
    ],
]

//  Convert the ETL Managed tags from the config to a list
List etlManagedTagsList = config.applicationBundleToTagLabel.values().toList()

//
// Convert a Comma Delimited String to a set
//
def commaStringToSet = { string  ->
    // Create the valueSet to be returned
    Set valueSet = []
    // Skip any Null values
    if(!string){
        return valueSet
    }
    // If the object is already a set, return it
    if(string.getClass().getName() == 'java.util.HashSet'){
        return string.valueSet().toList()
    }
    // Create a temporary list to hold the conversion results
    List list = []
    // If the String has a comma
    if(string.toString().indexOf(',') > -1){
       
        // Remove spaces after the commas
        string = string.replaceAll(', *', ',')
       
        // Fill the Temporary list with the values between the commas
        listItems = string.toString().tokenize(',')
        listItems.each { listItem ->
            list.add(listItem.trim())
        }
    }
    
    // The Value did not have a comma
    else {
        // Add the String to the list, all by it self
        list = [string.toString().trim()]
    }
    // Convert the temporary list to the Returned valueSet
    valueSet = list.toSet()
    return valueSet
}

// --------------------------
// Script logic
// --------------------------

read labels
iterate {

                //
                //            Get the Initial Asset Details
                //
    extract 'Asset Class' set assetClass
    extract 'Id' transform with toLong() set assetId
    
    // initalize tracking variables
    extract 'Tags' set existingAssetTagsValue
    extract 'Bundle' set existingAssetBundle
    Set existingAssetTagsList = []
    Set appBundleTagsSet = []
    Set assetTagsToAdd = []
    Set assetTagsToRemove = []

    // Convert the differing Tags format (Json Array when Bulk Edit, String when Excel)
    if(existingAssetTagsValue.getClass().getName() == 'java.lang.String'){
       
        // Convert "Comma, Separated, String" into ['Comma', 'Separated', 'String']
        existingAssetTagsList = commaStringToSet(existingAssetTagsValue)
       
    } else {
       
        // Collect just the tag names from the tag objects
        existingAssetTagsList = existingAssetTagsValue
    }

    //
   // Collect all of the application supports to assess application bundles
    //
        find Dependency by 'asset' eq assetId \
            fetch 'id', 'dependent', 'status', 'type' \
            set assetDependencies

    // iterate over each dependency to identify bundle of application
    if(assetDependencies.size() > 0) {
        assetDependencies.each { dependency ->
            if(dependency.dependent.assetClass.toString() == 'APPLICATION'){
                if(config.validDependencyStatus.contains(dependency.status) && config.validDependencyType.contains(dependency.type)){

                    // getting name of apps bundle
                    def appMoveBundleName = dependency.dependent.custom69.toString()

                    // only include bundles in the config map config.applicationBundleToTagLabel
                    if (config.applicationBundleToTagLabel.containsKey(appMoveBundleName)){

                            def newTagName = config.applicationBundleToTagLabel[appMoveBundleName]

                            assetTagsToAdd.add(newTagName)
                      
                    }
                }
            }
        }    
    }
    // Get the Asset Id and Class
    domain Device

    load 'Id' with assetId
    extract 'Name' load 'Name'

  
   
    // Filter the full list of ETL Managed tags
    assetTagsToRemove = etlManagedTagsList.findAll{ etlManagedTag ->
       
        // Return any tag that is already on the device,
        // but not ones that have been 'reafirmed' by existing in the 'assetTagsToAdd' list
        (
            existingAssetTagsList.contains(etlManagedTag) \
            && !assetTagsToAdd.contains(etlManagedTag)
        )
    }

    // Add collected tags to device
    assetTagsToAdd.each {
        tagAdd it
        }

    // Remove Tags from the device that are no longer valid
    assetTagsToRemove.each {
        tagRemove it
        }
}








