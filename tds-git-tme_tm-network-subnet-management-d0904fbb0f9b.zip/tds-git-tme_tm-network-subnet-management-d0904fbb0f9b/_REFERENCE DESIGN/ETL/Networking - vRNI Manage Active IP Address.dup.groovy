/*********TransitionManager-ETL-Script*********

{
  "EtlScriptName": "Networking - vRNI Manage Active IP Address",
  "Description": "Provide an Excel spreadsheet with Active IP Addresses. Each IP found within a TM Device will tag all matching devices with 'vRNI Active IP Found'. If there is no match, a basic IP Address device is created in the '4A Discovery-Unknown' bundle.",
  "ProviderName": "TransitionManager",
  "IsAutoProcess": false,
  "Target": null,
  "Mode": "Import"
}


*********TransitionManager-ETL-Script*********/

/*
    Networking - Manage vRNI Active IP Addresses



    Version: 1.0

    Summary:
        This script reads directly from the TM database.  It finds all devices which have an IP address.
        With this list, it makes a unique list of all IP addresses and records which assets have that IP address listed.
        With this 'Conflict List', each device is updated with a tag (Issue: IP Conflict) and a comment added for each conflicting IP address.
*/

List fetchFields = [
    'Id',
    'Name',
    'IP Address',
]

Map<Map> cache = [
    tmDevices: [:],
    ipAddresses: [:],
    deviceUpdates: [],
]

//////////////////////////////
// Script Functions
//////////////////////////////

// 
// Convert a Comma Delimited String to a set
// 
def commaStringToSet = { string  -> 

    // Create the valueSet to be returned
    Set valueSet = []

    // Skip any Null values
    if(!string){
        return valueSet
    }

    // Create a temporary list to hold the conversion results
    List list = []

    // If the String has a comma
    if(string.toString().indexOf(',') > -1){
        
        // Remove spaces after the commas
        string = string.replaceAll(', *', ',')
        
        // Fill the Temporary list with the values between the commas
        listItems = string.toString().tokenize(',')
        listItems.each { listItem ->
            list.add(listItem.trim())
        }
    } 
    
    // The Value did not have a comma
    else {

        // Add the String to the list, all by it self
        list = [string.toString().trim()]
    }

    // Convert the temporary list to the Returned valueSet
    valueSet = list.toSet()
    return valueSet
}
def addValueToExistingFieldList = { fieldName, addValues -> 

    // Wrap addValues as a List if it's not a List already
    List addValuesList = []
    def addValuesType = addValues.getClass().getName() 
    if(addValuesType == 'java.util.ArrayList'){
        addValuesList = addValues
    } 
    else if(addValuesType == 'java.util.HashSet'){
        addValuesList = addValues.toList()
    } else {
        addValuesList = [addValues]
    }

    // Ignore when findings are more than one asset (Safe for new assets (0) or single matches (1))
    if(FINDINGS.size() == 0){
        return addValuesList.join(',')
    
    }
    // Ignore when findings are more than one asset (Safe for new assets (0) or single matches (1))
    if(FINDINGS.size() == 1){
    
        // Get the Existing IP Address List
        List existingValuesList = []
        fetch 'id' fields 'Id', fieldName set existingFieldValue
        if(existingFieldValue && existingFieldValue.containsKey(fieldName) && existingFieldValue[fieldName]) {
            existingValuesList = existingFieldValue[fieldName].tokenize(',')
        } 
    
        // Get the existing IP data and merge the new (newIpList into it), return a string to store in TM
        existingValuesList.addAll(addValuesList)
        List combinedValuesList = existingValuesList.toSet().toList()
        String combinedValuesString = combinedValuesList.join(',')

        return combinedValuesString
    }

    // Zero or One record WAS not found.  This means multipe assets matched on the find
    return addValuesList.join(',')
}
def appendToStringSet = { string1, string2 -> 
    // Create Arrays
    List list1 = []
    List list2 = []

    // Update values if they're blank
    if(!string1){
        string1 = ''
    }
    if(!string2){
        string2 = ''
    }

    // Remove spaces around the commas
    string1 = string1.replaceAll(', ', ',')
    string2 = string2.replaceAll(', ', ',')

    if(string1.toString().indexOf(',') > -1){
        list1 = string1.toString().tokenize(',')
    } else {
        list1 = [string1.toString()]
    }

    if(string2.toString().indexOf(',') > -1){
        list2 = string2.toString().tokenize(',')
    } else {
        list2 = [string2.toString()]
    }
    
    // Combine the Lists into List 1
    list1.addAll(list2)
    def combinedValuesString = list1.toSet().toList().join(',')

    return combinedValuesString

}
//
// Test Device Name Conditions
//
def trimHostname = { assetName ->
    if(assetName && assetName.contains('.')){
        
        // If Asset Name is NOT an IP Address
        if(!assetName.matches(/^(?:[0-9]{1,3}\.){3}[0-9]{1,3}$/) ){
            
            // if the Name contains 'anz', it's most likely a hostname
            if(assetName.toLowerCase().matches(/.*(anz|unix|local|intranet|\.com).*/)){
                assetName = assetName.tokenize('.')[0]
            }
        }
    } 
    return assetName
}
//
// Get a listing of all the devices with IPs
//
find Device \
    by 'IP Address' ne '' \
    fetch 'Id', 'Name', 'IP Address' \
    set allDevices

//
// Iterate over each of the found devices
//
allDevices.each { device ->

    // Convert the IP and mac to a Set
    def ipSet = commaStringToSet(device.ipAddress)
    
    // Add each IP to the IP List
    ipSet.each { ip ->

        // Ignore useless values
        if(['', 'none', 'unknown', '0', '0.0.0.0'].contains(ip)){
            return
        }

        // Add the Device ID to the IP Address's set
        if(!cache.ipAddresses.containsKey(ip)){
            Set deviceSet = [device]
            cache.ipAddresses.put(ip, deviceSet)
            // Set deviceIdSet = [device.id]
            // cache.ipAddresses.put(ip, deviceIdSet)
        } else {
            cache.ipAddresses[ip].add(device)
            // cache.ipAddresses[ip].add(device.id)
        }
    }

    // Add the Device to the cache
    cache.tmDevices.putAt('TM' + device.id, [
        id: device.id,
        assetName: device.assetName,
        ipSet: ipSet,
    ])
}

// Iterate over Spreadsheet
sheet 'ip address vrni'
read labels
iterate {

    // Create a Device update record
    domain Device
    extract 'IP Address' set ipAddress
    if(cache.ipAddresses.containsKey(ipAddress)){
        
        // IP Address matched a known device,  Update the device
        def tmAssets = cache.ipAddresses.getAt(ipAddress)
        tmAssets.each { tmAsset ->


            // Update the device.  Get the Device name for convenient batch reviewing
            domain Device    
            load 'id' with tmAsset.id
            load 'Name' with tmAsset.assetName

            tagAdd 'vRNI Active IP Found'
            //load 'comments' with 'This device has an active IP Address from: ' + ipAddress + '.  ' + NOW

        }

    } else {
        
        // Create a Device from this info
        domain Device
        set assetName with 'vRNI IP: ' + ipAddress
        load 'Name' with assetName

        // Get and load the Mac and IP address
        //extract 'MAC Address' load 'Network - Mac Address'
        load 'IP Address' with ipAddress
        load 'Bundle' with '4A Discovery-Unknown'
        
        tagAdd 'vRNI Active IP Found'
        //load 'comments' with 'This device has an active IP Address: ' + ipAddress + '.  ' + NOW
        
        // // Extract Name field and parse it to get a hostname
        // extract 'NetBIOS Name' set deviceName
        // def netbiosDeviceName
        // if(deviceName && deviceName != ''){
        //     netbiosDeviceName = deviceName.substring((deviceName.indexOf('\\') + 1),deviceName.length())
        // }
        // // Extract DNS Name field and parse it to get a hostname
        // extract 'DNS Name' set dnsName load 'Network - Hostname'
        // def dnsHostname
        // if(dnsName && dnsName !=''){
        //     dnsHostname = trimHostname(dnsName)
        // }

        // // Ensure a proper Asset Name. Some values are blank.
        // def assetName 
        // if(netbiosDeviceName){
        //     assetName = netbiosDeviceName
        // } else if(dnsHostname) {
        //     assetName = dnsHostname
        // } else {
            // assetName = 'IP: ' + ipAddress
        // }
        // set assetName with 'IP: ' + ipAddress
        // load 'Name' with assetName

        // // Get and load the Mac and IP address
        // extract 'MAC Address' load 'Network - Mac Address'
        // load 'IP Address' with ipAddress
        // load 'Bundle' with 'DS Inbox - TM Networking'

        // Find the Device by name
        // find Device by 'Name' eq assetName into 'id'
        
        // // If the device is new
        // if(FINDINGS.size() == 0) {
            // load 'Bundle' with 'DS Inbox - TM Networking'
        // }
        
        // // If findings found 1 asset.
        // if(FINDINGS.size() == 1) {
            
        //     // Get the existing record to combine Macs and IPs
        //     fetch 'id' fields 'Id', 'IP Address', 'Network - Mac Address' set existingFieldValue
        //     // def ipString = addValueToExistingFieldList('IP Address', ipAddress)
            
        //     // Overload the IP address field with the combined list of IPs
        //     ipString = appendToStringSet(existingFieldValue['IP Address'], ipAddress)
        //     macString = appendToStringSet(existingFieldValue['Network - Mac Address'], macAddress)

        //     load 'IP Address' with ipString
        //     load 'Network - Mac Address' with macString

        // }

        // tagAdd 'Active IP Found'
        // load 'comments' with 'This device has an active IP Address: ' + ipAddress + '.  ' + NOW
    }
}








